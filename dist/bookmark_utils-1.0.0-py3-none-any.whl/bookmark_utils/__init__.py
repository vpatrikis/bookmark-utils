def main():
    print("This is bookmarks utility")
